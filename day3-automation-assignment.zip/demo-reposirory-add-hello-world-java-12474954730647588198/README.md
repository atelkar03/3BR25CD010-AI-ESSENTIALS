# Hello World

## Description
A simple Java program that prints **"Hello, World!"** to the console.

## Technologies Used
- Java

## How to Run

1. Make sure Java is installed on your system.
2. Compile the program:
   ```bash
   javac HelloWorld.java
